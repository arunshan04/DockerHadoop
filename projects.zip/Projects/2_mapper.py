#!/usr/bin/python
import sys;

for line in sys.stdin:
    line = line.strip()
    line=line.replace('"','')
    words = line.split(',')
    if words[0] == "Connecticut":
       print '%s\t%s' % (words[0],1)
