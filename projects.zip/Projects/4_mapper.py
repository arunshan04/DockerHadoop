#!/usr/bin/python
import sys;

for line in sys.stdin:
    line = line.strip()
    line=line.replace('"','')
    words = line.split(',')
    if words[2].isdigit():
       print '%s\t%s\t%s' % (words[5],words[4],1)
