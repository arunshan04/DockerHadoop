import pandas as pd

# del write_df_to_mongoDB
def write_df_to_mongoDB(  my_df,\
                          database_name = 'mydatabasename' ,\
                          collection_name = 'mycollectionname',
                          server = 'localhost',\
                          mongodb_port = 27017,\
                          chunk_size = 10):
    from pymongo import MongoClient
    client = MongoClient('localhost',int(mongodb_port))
    db = client[database_name]
    collection = db[collection_name]
    # To write
    collection.delete_many({})  # Destroy the collection
    #aux_df=aux_df.drop_duplicates(subset=None, keep='last') # To avoid repetitions
    my_list = my_df.to_dict('records')
    l =  len(my_list)
    j=0
    for i in range(0, l, chunk_size):
        collection.insert_many(my_list[i:i+chunk_size])
        j+=1

    print('Processed {} Records in {} loops'.format(l,j))
    return
    
df=pd.read_csv('accidental-drug-related-deaths-by-drug-type2012-2018.csv')
write_df_to_mongoDB(df,database_name='datadb',collection_name='medic',chunk_size=100000)
