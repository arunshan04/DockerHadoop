#!/usr/bin/python
import sys;

for line in sys.stdin:
    line = line.strip()
    line=line.replace('"','')
    words = line.split(',')
    if words[2].isdigit():
       if (int(words[2]) >= 2012 and  int(words[2]))  <= 2018 and ( words[0]=="Connecticut"):
           print("\t".join(words))
