#!/usr/bin/python
import sys
prev_group1=None
prev_group2=None
cnt=0
for line in sys.stdin:
   line = line.strip()
   line = line.split('\t')
   group1=line[0]
   group2=line[1]
   #print('****',prev_group1,group1,prev_group2,group2)
   if ( group1 != prev_group1 or  group2 != prev_group2 ) or ( prev_group1 == None or  prev_group2 ==None ):
        if prev_group1:
            print('%s\t%s\t%s' % (prev_group1,prev_group2,cnt))
        cnt=1
   else:
        cnt=cnt+1
   prev_group1=group1
   prev_group2=group2
if group1:
    print('%s\t%s\t%s' % (group1,group2,cnt))
